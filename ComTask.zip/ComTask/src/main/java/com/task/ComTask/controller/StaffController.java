package com.task.ComTask.controller;

import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.task.ComTask.service.StaffService;
import com.task.ComTask.staff.Staff;

@RestController
public class StaffController {
	
	@Autowired
	StaffService s;
	
	//1. To get all data from database
	@GetMapping("/getAll")
	public List<Staff> getRecord(){
		
		return s.getRecord();
	}
	
	//2. To get staff whose id is 3
	@GetMapping("/getRecById/{sid}")
	public List<Staff> getRecById(@PathVariable int sid){
		return s.getRecById(sid);
	}
	
	
	//3. To insert one staff into the database
	
	@PostMapping("/insertOneData")
	public String insertOneData(@RequestBody Staff st) {
		String msg = s.insertOneData(st);
		return msg;
	}
	
	//4. Api to get staff whose salary is more than 20000
	@GetMapping("/salMoreTh/{sal}")
	public List<Staff> salMoreTh(@PathVariable long sal){
		
		return s.salMoreTh(sal);
	}
	
	//5. Api to get Staff who has experience between 10 to 20
	
	@GetMapping("/recByEx/{low}/{high}")
	public List<Staff> recByEx(@PathVariable int low,@PathVariable int high) {
		return s.recByEx(low,high);
	}
	

	//6. Api whose salary is maximum
	@GetMapping("/findMaxSal")
	public List<Staff> findMaxSal() {
		List<Staff> li = s.getRecord();
		ArrayList<Long> al = new ArrayList<>();
		
		for (Staff staff : li) {
			al.add(staff.getSalary());
		}
		Collections.sort(al);
		long fin = al.get(al.size()-1);
		
		List<Staff> sl = s.findMaxSal(fin);
		return sl;
	}
	
	//7. Update Data whose id is 4
	@PutMapping("/updateData")
	public String updateData(@RequestBody Staff st) {
		String msg = s.updateData(st);
		return msg;
	}
	
	//8. Api to display name whose experience is minimum
	@GetMapping("/minExp")
	public String minExp() {
		List<Staff> li = s.getRecord();
		ArrayList<Integer> al = new ArrayList<>();
		for (Staff staff : li) {
			al.add(staff.getExperience());
		}
		Collections.sort(al);
		int fin = al.get(0);
		List<Staff> lr = s.minExp(fin);
		String st="";
		for (Staff staff : lr) {
			st = staff.getName();
		}
		return st;
	}
	
	//9. Api to get staff whose profile is trainer
	
	@GetMapping("/getTr/{trainer}")
	public List<Staff> getTr(@PathVariable String trainer) {
		return s.getTr(trainer);
	}
	
	//10. Api to get staff whose profile is no trainer
	
	@GetMapping("/getNeTr/{trainer}")
	public List<Staff> getNeTr(@PathVariable String trainer){
		return s.getNeTr(trainer);
	}
	
	
}
