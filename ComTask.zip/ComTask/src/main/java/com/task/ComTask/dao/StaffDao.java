package com.task.ComTask.dao;

import java.util.List;

import org.hibernate.Criteria;
import org.hibernate.Session;
import org.hibernate.SessionFactory;
import org.hibernate.Transaction;
import org.hibernate.criterion.Restrictions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import com.task.ComTask.staff.Staff;

@Repository
public class StaffDao {
	
	@Autowired
	SessionFactory sf;

	public List<Staff> getRecord() {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		return cr.list();
	}

	public List<Staff> getRecById(int sid) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.eq("staffid", sid));
		return cr.list();
	}

	public String insertOneData(Staff st) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		session.save(st);
		tr.commit();
		return "Data Inserted";
	}

	public List<Staff> salMoreTh(long sal) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.gt("salary", sal));
		return cr.list();
	}

	public List<Staff> recByEx(int low, int high) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.between("experience", low, high));
		return cr.list();
	}

	public List<Staff> findMaxSal(long fin) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.eq("salary", fin));
		return cr.list();
	}

	public String updateData(Staff st) {
		Session session = sf.openSession();
		Transaction tr = session.beginTransaction();
		Staff s = new Staff();
		s.setStaffid(4);
		s.setSalary(st.getSalary());
		s.setName(st.getName());
		s.setProfile(st.getProfile());
		s.setExperience(st.getExperience());
		session.update(s);
		tr.commit();
		return "Data Updated";
	}

	public List<Staff> minExp(int fin) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.eq("experience", fin));
		
		return cr.list();
	}

	public List<Staff> getTr(String trainer) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.eq("profile", trainer));
		return cr.list();
	}

	public List<Staff> getNeTr(String trainer) {
		Session session = sf.openSession();
		Criteria cr = session.createCriteria(Staff.class);
		cr.add(Restrictions.ne("profile", trainer));
		return cr.list();
	}
	
	

}
