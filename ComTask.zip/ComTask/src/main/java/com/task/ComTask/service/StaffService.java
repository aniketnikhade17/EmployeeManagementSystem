package com.task.ComTask.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.task.ComTask.dao.StaffDao;
import com.task.ComTask.staff.Staff;

@Service
public class StaffService {
	@Autowired
	StaffDao d;


	public List<Staff> getRecord() {
		// TODO Auto-generated method stub
		return d.getRecord();
	}


	public List<Staff> getRecById(int sid) {
		
		return d.getRecById(sid);
	}


	public String insertOneData(Staff st) {
		String msg = d.insertOneData(st);
		return msg;
	}


	public List<Staff> salMoreTh(long sal) {
		return d.salMoreTh(sal);
	}


	public List<Staff> recByEx(int low, int high) {
		
		return d.recByEx(low,high);
	}


	public List<Staff> findMaxSal(long fin) {
		
		return d.findMaxSal(fin);
	}


	public String updateData(Staff st) {
		String msg = d.updateData(st);
		return msg;
	}


	public List<Staff> minExp(int fin) {
		
		return d.minExp(fin);
	}


	public List<Staff> getTr(String trainer) {
		
		return d.getTr(trainer);
	}


	public List<Staff> getNeTr(String trainer) {
		
		return d.getNeTr(trainer);
	}
	
	

}
